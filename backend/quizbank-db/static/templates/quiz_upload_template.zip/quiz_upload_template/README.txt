====================================
QUIZBANK UPLOAD TEMPLATE GUIDE
====================================

Your upload can take one of the following forms:

1️⃣  **Single questions.csv file**
    → For assessments that do NOT use shared contexts or attachments.
    → Upload this file directly (no need to ZIP).

2️⃣  **ZIP package (recommended for structured uploads)**
    → Must contain at least:
        - questions.csv
    → May also include:
        - context.csv  (if any questions share the same background text)
        - attachments (supporting files like images or data)

------------------------------------
FILE NAMING CONVENTION
------------------------------------
Follow this naming format for CSVs:

COURSECODE_SemX_YYYY_AssessmentTitle_questions.csv  
COURSECODE_SemX_YYYY_AssessmentTitle_context.csv  

**Example:**
DSA1101_Sem1_2425_Finals_questions.csv  
DSA1101_Sem1_2425_Finals_context.csv  

This helps QuizBank automatically identify:
- Course (e.g., DSA1101)
- Semester (e.g., Sem1)
- Academic Year (e.g., 2425)
- Assessment Title (e.g., Finals)
- File Type (questions / context)

------------------------------------
WHEN TO INCLUDE CONTEXTS
------------------------------------
Add a **context.csv** only when:
- Two or more questions share the same scenario, dataset, or description.

Each context must have a unique Context ID.
  - The `Column Text` stores the full background.
  - In your questions.csv, use the same `Context ID` to link questions.


------------------------------------
HOW TO HANDLE ATTACHMENTS
------------------------------------
If your questions or contexts reference external files:
1. Reference their filenames exactly in the `Attachments` column.
   - Example: DSA1101_Finals_Figure1.png
   - For multiple attachments: separate with commas
     → e.g. `data.csv, DSA1101_FigA.png`
2. Attachment filenames must be unique within one upload.

------------------------------------
SUPPORTED ATTACHMENT TYPES
------------------------------------
**Images**
  .png, .jpg, .jpeg

**Documents**
  .pdf, .doc, .txt, .md

**Data & Code**
  .r, .rmd, .py, .ipynb, .json, .xml, .csv

**Archives**
  .zip

**Others**
  .html, .css, .js

------------------------------------
COLUMN DESCRIPTIONS
------------------------------------

🟦 context.csv
| Column | Description |
|---------|--------------|
| context_id | A short unique label (e.g., C1, C2) used to link related questions. |
| context_text | Background or description shared by related questions. |
| attachments | (Optional) Comma-separated filenames for any figures or datasets used in this context. |

🟩 questions.csv
| Column | Description |
|---------|--------------|
| context_id | Links to the corresponding context in context.csv (if applicable). |
| question_number | Main question number (e.g., 1, 2, 3). |
| sub_question_number | For subparts (e.g., 1.1, 1.2). Leave blank if not applicable. |
| question_text | The full question content. |
| question_type | One of: MCQ, MRQ, SRQ, Code, T/F. |
| option_a → option_e | Only for T/F, MCQ and MRQ. |
| correct_answer | (Optional) Correct response(s). Use “A”, “A,B”, or text as appropriate. |
| explanation | (Optional) clarifying note or worked solution. |
| points | (Optional) Marks allocated to this question. |
| difficulty | One of: low / med / high. |
| concepts | Keywords for tagging the question topic (e.g., regression, hypothesis testing). |
| attachments | (Optional) Comma-separated filenames of any files used in this question. |

------------------------------------
UPLOAD INSTRUCTIONS
------------------------------------
1. Fill in questions.csv (and context.csv if needed).
   - Ensure all required columns are filled.
   - Keep Context ID consistent across files.

2. If using attachments:
   - Include all referenced files.

3. Compress all files into one ZIP if contexts or attachments exist. Name all files according to the naming convention. Do not include this README file in your ZIP file when uploading.

4. Upload to QuizBank via the Upload page.

------------------------------------
VALIDATION & ERRORS
------------------------------------
After upload, the system will:
- Check for missing or invalid data
- Flag duplicates or broken links
- Display row-level error messages

Upload completes only when all checks pass ✅

------------------------------------
TROUBLESHOOTING
------------------------------------
❌ Upload rejected?
- Ensure filenames follow the format.
- Check that questions.csv exists.
- Verify attachment names match exactly.
- Make sure all Context ID references exist in context.csv.

